/* Study notes, IN C FORM! */

