/* ITS OVER 9000! */
#include <stdio.h>
int main(void)
{
int i;
char enter;
printf("VEGETA, WHAT DOES THE SCOUTER SAY ABOUT HIS POWER LEVEL?!?\n");
scanf("%c", &enter);
for(i = 0; ; i++){
printf("                                                                           \n");
printf("IT'S OVER 9000!IT'S OVER 9000!IT'S OVER 9000!IT'S OVER 9000!IT'S OVER 9000!\n");
printf("                                                                           \n");
}
return(0);
}
