/* Programming project 3, THE GAME OF LIFE */
/* Made by Tyler Holland, CPE101-01/02 */

/* Declarations */
#include <stdio.h>
#define BOARDH 20 /* Board height */
#define BOARDW 20 /* Board width */
/* Function Prototypes: */

void PrintSetup(void)
{

}

int Setup(int liveArray[])
{
   int x;
   int y;
   int sentinel;
   int generations
}

void TheGame(int liveArray[], int tempArray[], int generations)
{

}

void Copier(int liveArray[], int tempArray[])
{

}

void Change(int tempArray[], int liveArray[])
{

}

void Printer(int liveArray[])
{

}

int NumLiving(int tempArray[])
{
   int numLive;

}

/* Start main function */
int main(void)
{
   /* Variables */
   int gameBoard[BOARDH + 2][BOARDW + 2]; /* Game board, +2 for border blanks */
   return(0);
}
