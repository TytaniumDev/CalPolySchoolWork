
public class driver
{
   public static void main(String[] args)
   {
      new MovieStats("test.txt");
   }


}
