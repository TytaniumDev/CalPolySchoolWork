/**
 * Practice with ArrayLists and adding things to them
 *
 * @author Tyler Holland
 * @version Lab 2
 * @version CPE102-5
 * @version Winter 2009
 */
   import java.util.ArrayList;

    public class LabTwo
   {
   // Instance variables
      private ArrayList<Integer> intList; // = new ArrayList<Integer>();
      private ArrayList<Double> doubleList; // = new ArrayList<Double>();
      private ArrayList<Boolean> booleanList; // = new ArrayList<Boolean>();
      private ArrayList<String> stringlist; // = new ArrayList<String>();
   
   // Constructors
   
   //Methods
       public void add(String input)
      {
         if(input != null)
         {
            intList.add(input);
         }
      }
       public void add(int input)
      {
      
      }
       public void add(double input)
      {
      
      }
       public void add(boolean input)
      {
      
      }
   }