
public class Driver
{
   public static void main(String[] args)
   {
      Fibonacci test = new Fibonacci();

      for(Double d : test)
      {
         System.out.println("" + d);
      }
   }
}
