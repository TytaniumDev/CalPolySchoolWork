/*
local defines and declarations 
*/

extern unsigned char imgrd[];
extern size_t imgrd_size;
