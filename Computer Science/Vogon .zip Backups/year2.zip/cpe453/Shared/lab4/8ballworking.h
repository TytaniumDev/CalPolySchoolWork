#ifndef __BALL_H
#define __BALL_H

/** The Hello, World! message. */
#define BALL_MESSAGE "Hello,New World!\n"

/*Major ID of /dev/8ball. */
#define BALL_MAJOR 18

#endif /*__BALL_H*/
