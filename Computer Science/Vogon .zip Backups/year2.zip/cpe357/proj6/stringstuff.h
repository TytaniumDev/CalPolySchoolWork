#ifndef STRINGSTUFFH
#define STRINGSTUFFH
#include <string.h>

extern int countlines(char *str);
extern int matchquotes(char *str);
extern char *cleancpystring(char *s);

#endif
