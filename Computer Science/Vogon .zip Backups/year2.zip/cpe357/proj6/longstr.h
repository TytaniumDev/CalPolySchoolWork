#ifndef LONGSTRH
#define LONGSTRH
#include <stdio.h>
char *readLongString(FILE *infile);
#endif
