#define T_string 257
#define T_pipe 258
#define T_into 259
#define T_from 260
#define T_newline 261
#define T_badstring 262
