Name: Tyler Holland
Assignment: Project 1
Instructions: Compiles with make
Runtime: works exactly like expand
Additional input:
   I found that with expand, typing in "expand -30 test.txt" would
   do the same thing as if you were to type "expand -t 30 test.txt",
   so I implemented my program the same way. This was not mentioned in
   the project page however.

   Also, if you enter something such as detab --tabs=18 --tabs=10 file.txt,
   the program will set the tab stop to the second value (10). In expand,
   having multiple --tabs= declarations in the command line ran the
   --tabs=LIST function that we did not have to implement, so I chose the
   above solution instead.
