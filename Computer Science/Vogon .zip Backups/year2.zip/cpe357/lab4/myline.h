/* Header file for project 2
 * Made by Tyler Holland
 * Class: CPE357
 */
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

 ssize_t myline(char **lineptr, size_t *n, FILE *stream);
