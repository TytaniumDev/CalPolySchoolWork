#!/bin/bash

echo TeacherHome [Press Enter]; read; prototype.sh TeacherHome;
echo QuestionDB [Press Enter]; read; prototype.sh QuestionDB;
echo AddGeneric [Press Enter]; read; prototype.sh AddQuestionGeneric;
echo AddMult [Press Enter]; read; prototype.sh AddMultipleChoiceQuestion;
echo AddProgram [Press Enter]; read; prototype.sh AddProgrammingQuestion;
echo AddShortAnswer [Press Enter]; read; prototype.sh AddShortAnswerQuestion;
echo TestGen [Press Enter]; read; prototype.sh TestGen;
echo Proctor [Press Enter]; read; prototype.sh ProctorMain;
echo StudentHome [Press Enter]; read; prototype.sh StudentHome;
echo StudentTrueFalse [Press Enter]; read; prototype.sh StudentTrueFalse;
echo TestGrade [Press Enter]; read; prototype.sh testGrade;
echo QuestGrade [Press Enter]; read; prototype.sh gradeQuest;
