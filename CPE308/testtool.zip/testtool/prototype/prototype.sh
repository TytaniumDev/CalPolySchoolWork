#!/bin/bash

cd $1/dist
java -jar $1.jar
